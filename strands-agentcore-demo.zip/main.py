def main():
    print("Hello from strands-agentcore-demo!")


if __name__ == "__main__":
    main()
